const fs=require('node:fs'),path=require('node:path');
const root='/home/wijreid/Desktop/SAIL/SAIL_Engineering/GitHub_tariff-rate-tracker/tariff-rate-tracker';
const req=require('node:module').createRequire(path.join(root,'frontend/package.json'));
req('dotenv').config({path:path.join(root,'.env'),quiet:true});
if(!process.env.MOTHERDUCK_TOKEN)throw new Error('Missing configured MotherDuck token');
process.env.motherduck_token=process.env.MOTHERDUCK_TOKEN;
(async()=>{const {DuckDBInstance}=req('@duckdb/node-api');const i=await DuckDBInstance.create('md:duty_calculator',{access_mode:'READ_ONLY'}),c=await i.connect();try{
 if((await c.runAndReadAll('SELECT current_database() AS catalog_name')).getRowObjects()[0].catalog_name!=='duty_calculator')throw new Error('Wrong catalog');
 await c.run('BEGIN TRANSACTION READ ONLY');
 const sql="SELECT revision,COUNT(*)::VARCHAR row_count,COUNT(DISTINCT hts10)::VARCHAR hts10_count,COUNT(DISTINCT country)::VARCHAR origin_count,MIN(valid_from)::VARCHAR first_date,MAX(valid_until)::VARCHAR last_date,SUM(CASE WHEN statutory_rate_232>0 AND statutory_rate_s301fl>0 AND valid_until>=CAST('2026-07-24' AS DATE) THEN 1 ELSE 0 END)::VARCHAR stored_positive_s232_and_forced_labor_rows FROM rates WHERE revision LIKE '2025_%' OR revision LIKE '2026_%' GROUP BY revision ORDER BY revision";
 const params=[];const rows=(await c.runAndReadAll(sql,params)).getRowObjects();
 await c.run('ROLLBACK');
 fs.writeFileSync('/tmp/shipment-gap-closure-20261027/motherduck-grid-counts.json',JSON.stringify({catalog:'duty_calculator',access_mode:'READ_ONLY',sql,params,rows},null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify(rows));
}finally{c.closeSync();i.closeSync();}})().catch(e=>{console.error(e.message);process.exitCode=1;});
