const fs=require('node:fs'),path=require('node:path');
const root='/home/wijreid/Desktop/SAIL/SAIL_Engineering/GitHub_tariff-rate-tracker/tariff-rate-tracker';
const req=require('node:module').createRequire(path.join(root,'frontend/package.json'));
req('dotenv').config({path:path.join(root,'.env'),quiet:true});
if(!process.env.MOTHERDUCK_TOKEN)throw new Error('Missing configured MotherDuck token');
process.env.motherduck_token=process.env.MOTHERDUCK_TOKEN;
(async()=>{const {DuckDBInstance}=req('@duckdb/node-api');const i=await DuckDBInstance.create('md:duty_calculator',{access_mode:'READ_ONLY'}),c=await i.connect();try{
 if((await c.runAndReadAll('SELECT current_database() AS catalog_name')).getRowObjects()[0].catalog_name!=='duty_calculator')throw new Error('Wrong catalog');
 await c.run('BEGIN TRANSACTION READ ONLY');
 const sql="WITH entries(entry_day) AS (VALUES (CAST('2026-09-30' AS DATE)),(CAST('2026-10-10' AS DATE)),(CAST('2026-10-22' AS DATE))) SELECT entry_day::VARCHAR entry_day,COUNT(*)::VARCHAR matched_rows,COUNT(DISTINCT (hts10,country))::VARCHAR unique_product_origins,COUNT(*)-COUNT(DISTINCT (hts10,country)) AS surplus_candidate_rows FROM rates JOIN entries ON valid_from<=entry_day AND valid_until>=entry_day GROUP BY entry_day ORDER BY entry_day";
 const params=[];const rows=(await c.runAndReadAll(sql,params)).getRowObjects();
 await c.run('ROLLBACK');
 fs.writeFileSync('/tmp/shipment-gap-closure-20261027/motherduck-date-ambiguity.json',JSON.stringify({catalog:'duty_calculator',access_mode:'READ_ONLY',sql,params,rows},(_k,v)=>typeof v==='bigint'?v.toString():v,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify(rows,(_k,v)=>typeof v==='bigint'?v.toString():v));
}finally{c.closeSync();i.closeSync();}})().catch(e=>{console.error(e.message);process.exitCode=1;});
